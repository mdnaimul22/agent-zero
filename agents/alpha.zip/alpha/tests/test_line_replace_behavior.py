import unittest
import os
import sys
import asyncio

# Add the project root to the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from python.tools.line_replace import MultiLineReplacer

class TestLineReplacerBehavior(unittest.TestCase):

    def setUp(self):
        """Set up a temporary file for testing."""
        self.temp_file_path = "temp_test_file.txt"
        with open(self.temp_file_path, 'w') as f:
            f.write("line 1\n")
            f.write("line 2\n")
            f.write("line 3\n")
            f.write("line 4\n")
            f.write("line 5\n")

    def tearDown(self):
        """Clean up the temporary file."""
        if os.path.exists(self.temp_file_path):
            os.remove(self.temp_file_path)

    def test_no_effective_change(self):
        """Test that no change is reported when content is the same."""
        replacer = MultiLineReplacer()
        changes = [{
            "line_start": 2,
            "line_end": 2,
            "new_content": "line 2\n",
            "operation": "replace"
        }]

        print("\n--- Running test_no_effective_change ---")
        with open(self.temp_file_path, 'r') as f:
            print("Initial content:")
            print(f.read())
        print("Changes to apply:")
        import json
        print(json.dumps(changes, indent=2))

        response = asyncio.run(replacer.execute(target_file=self.temp_file_path, changes=changes))

        print("Final content:")
        with open(self.temp_file_path, 'r') as f:
            print(f.read())
        print("Tool response:")
        print(response.message)
        print("--- Finished test_no_effective_change ---\n")

        self.assertIn("No effective changes applied", response.message)

    def test_multiline_replacement(self):
        """Test that a multi-line replacement is applied correctly."""
        replacer = MultiLineReplacer()
        new_multiline_content = "new line 2\nnew line 3\n"
        changes = [{
            "line_start": 2,
            "line_end": 3,
            "new_content": new_multiline_content,
            "operation": "replace"
        }]

        print("\n--- Running test_multiline_replacement ---")
        with open(self.temp_file_path, 'r') as f:
            print("Initial content:")
            print(f.read())
        print("Changes to apply:")
        import json
        print(json.dumps(changes, indent=2))

        response = asyncio.run(replacer.execute(target_file=self.temp_file_path, changes=changes))

        with open(self.temp_file_path, 'r') as f:
            content = f.read()
        print("Final content:")
        print(content)
        print("Tool response:")
        print(response.message)
        print("--- Finished test_multiline_replacement ---\n")

        expected_content = "line 1\nnew line 2\nnew line 3\nline 4\nline 5\n"
        self.assertEqual(content, expected_content)

    def test_multiple_large_chunk_replacements(self):
        """Test replacing multiple, non-contiguous chunks in one call."""
        replacer = MultiLineReplacer()
        
        chunk1 = "--- start chunk 1 ---\nthis is the first replacement\n--- end chunk 1 ---\n"
        chunk2 = "=== start chunk 2 ===\n=== end chunk 2 ===\n"

        changes = [
            {
                "line_start": 2, "line_end": 2, "new_content": chunk1, "operation": "replace"
            },
            {
                "line_start": 4, "line_end": 4, "new_content": chunk2, "operation": "replace"
            }
        ]

        print("\n--- Running test_multiple_large_chunk_replacements ---")
        with open(self.temp_file_path, 'r') as f:
            print("Initial content:")
            print(f.read())
        print("Changes to apply:")
        import json
        print(json.dumps(changes, indent=2))

        response = asyncio.run(replacer.execute(target_file=self.temp_file_path, changes=changes))

        with open(self.temp_file_path, 'r') as f:
            content = f.read()
        print("Final content:")
        print(content)
        print("Tool response:")
        print(response.message)
        print("--- Finished test_multiple_large_chunk_replacements ---\n")

        expected_content = (
            "line 1\n"
            "--- start chunk 1 ---\n"
            "this is the first replacement\n"
            "--- end chunk 1 ---\n"
            "line 3\n"
            "=== start chunk 2 ===\n"
            "=== end chunk 2 ===\n"
            "line 5\n"
        )
        self.assertEqual(content, expected_content)

    def test_accurate_error_line_number(self):
        """Test that syntax error line numbers are reported correctly."""
        py_file_path = "temp_test_script.py"
        with open(py_file_path, 'w') as f:
            f.write("def my_function():\n")
            f.write("    print('hello')\n")
            f.write("\n")
            f.write("my_function()\n")

        replacer = MultiLineReplacer()
        changes = [{
            "line_start": 2,
            "line_end": 2,
            "new_content": "    print 'hello' # Invalid syntax in Python 3",
            "operation": "replace"
        }]

        print("\n--- Running test_accurate_error_line_number ---")
        with open(py_file_path, 'r') as f:
            print("Initial content:")
            print(f.read())
        print("Changes to apply:")
        import json
        print(json.dumps(changes, indent=2))

        response = asyncio.run(replacer.execute(target_file=py_file_path, changes=changes, strict_mode=False))

        print("Final content:")
        with open(py_file_path, 'r') as f:
            print(f.read())
        print("Tool response:")
        print(response.message)
        print("--- Finished test_accurate_error_line_number ---\n")

        os.remove(py_file_path)

        self.assertIn("ERRORS DETECTED", response.message)
        self.assertIn("at line 2", response.message)

    def test_complex_mixed_operations(self):
        """Test a complex mix of replace, delete, and insert operations."""
        large_file_path = "temp_large_test_file.txt"
        with open(large_file_path, 'w') as f:
            for i in range(1, 51):
                f.write(f"Line {i} of 50\n")

        replacer = MultiLineReplacer()

        changes = [
            {
                "line_start": 4,
                "line_end": 10,
                "new_content": "def improved_function():\n    return optimized_code\n",
                "operation": "replace"
            },
            {
                "line_start": 25,
                "line_end": 30,
                "operation": "delete"
            },
            {
                "line_start": 45,
                "new_content": "# Added new comment\nnew_variable = calculate_value()\n",
                "operation": "insert"
            }
        ]

        print("\n--- Running test_complex_mixed_operations ---")
        with open(large_file_path, 'r') as f:
            print("Initial content:")
            print(f.read())
        print("Changes to apply:")
        import json
        print(json.dumps(changes, indent=2))

        response = asyncio.run(replacer.execute(target_file=large_file_path, changes=changes))

        with open(large_file_path, 'r') as f:
            content = f.read()
        print("Final content:")
        print(content)
        print("Tool response:")
        print(response.message)
        print("--- Finished test_complex_mixed_operations ---\n")

        expected_lines = [f"Line {i} of 50\n" for i in range(1, 51)]
        expected_lines.insert(44, "# Added new comment\nnew_variable = calculate_value()\n")
        del expected_lines[24:30]
        expected_lines[3:10] = ["def improved_function():\n", "    return optimized_code\n"]
        expected_content = "".join(expected_lines)

        self.assertEqual(content, expected_content)

        os.remove(large_file_path)

    def test_multiple_replace_operations(self):
        """Test multiple, non-contiguous replace operations in a single call."""
        large_file_path = "temp_multi_replace_file.txt"
        with open(large_file_path, 'w') as f:
            for i in range(1, 51):
                f.write(f"Original Line {i}\n")

        replacer = MultiLineReplacer()

        changes = [
            {
                "line_start": 2,
                "line_end": 5,
                "new_content": "--- TOP REPLACEMENT ---\n",
                "operation": "replace"
            },
            {
                "line_start": 22,
                "line_end": 28,
                "new_content": "--- MIDDLE REPLACEMENT ---\n",
                "operation": "replace"
            },
            {
                "line_start": 45,
                "line_end": 48,
                "new_content": "--- BOTTOM REPLACEMENT ---\n",
                "operation": "replace"
            }
        ]

        print("\n--- Running test_multiple_replace_operations ---")
        with open(large_file_path, 'r') as f:
            print("Initial content:")
            print(f.read())
        print("Changes to apply:")
        import json
        print(json.dumps(changes, indent=2))

        response = asyncio.run(replacer.execute(target_file=large_file_path, changes=changes))

        with open(large_file_path, 'r') as f:
            content = f.read()
        print("Final content:")
        print(content)
        print("Tool response:")
        print(response.message)
        print("--- Finished test_multiple_replace_operations ---\n")

        expected_lines = [f"Original Line {i}\n" for i in range(1, 51)]
        expected_lines[44:48] = ["--- BOTTOM REPLACEMENT ---\n"]
        expected_lines[21:28] = ["--- MIDDLE REPLACEMENT ---\n"]
        expected_lines[1:5] = ["--- TOP REPLACEMENT ---\n"]
        expected_content = "".join(expected_lines)

        self.assertEqual(content, expected_content)

        os.remove(large_file_path)

if __name__ == '__main__':
    unittest.main()
