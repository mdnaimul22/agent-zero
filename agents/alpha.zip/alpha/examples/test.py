import sys
sys.path.append('/home/naimul/a1')
import asyncio
from pathlib import Path
import os

from alpha.main import run_evolution


async def main():
    # The task is to evolve a function that can intelligently modify a file based on a natural language instruction.
    # This function, `find_and_apply_change`, will replace the brittle, line-number-based logic of the
    # current `line_replace.py` tool. It needs to understand the user's intent and locate the correct
    # code block to modify, even if the file's structure has changed.

    task_description = """
    You are an expert programmer tasked with evolving a function that can intelligently modify a file's content.
    The function `find_and_apply_change(file_content: str, instruction: str) -> str:` takes the full content
    of a file and a natural language instruction, and returns the modified content.

    Your evolved function should be able to:
    1.  Parse the `file_content` to understand its structure (e.g., functions, classes, variables).
    2.  Interpret the `instruction` to determine the user's intent (e.g., replace a function, add a parameter, delete a class).
    3.  Locate the precise code block to be modified based on the instruction, without relying on line numbers.
    4.  Apply the change accurately and return the full, updated `file_content`.
    5.  If the instruction is unclear or the target code cannot be found, it should return the original content unchanged.
    """

    # This is our starting point. It's a very basic implementation that we will evolve.
    initial_program = """'

def find_and_apply_change(file_content: str, instruction: str) -> str:
    if not file_content.strip():
        return file_content
    
    if not instruction.strip():
        return file_content
    
    vague_instructions = ['make it better', 'improve', 'fix it', 'optimize']
    if any(vague in instruction.lower() for vague in vague_instructions):
        return file_content
    
    try:
        tree = ast.parse(file_content)
    except SyntaxError:
        return file_content
    
    modifier = CodeModifier(instruction)
    new_tree = modifier.visit(tree)
    
    if not modifier.modified:
        return file_content
    
    try:
        new_code = ast.unparse(new_tree)
        return new_code
    except Exception:
        return file_content
'"""

    # These test cases will guide the evolution. They cover a range of common code modification tasks.
    test_cases = [
        {
            "description": "Replace a simple function's body.",
            "file_content": "def foo():\n    return 1\n",
            "instruction": "In function foo, change the return value to 2.",
            "expected_output": "def foo():\n    return 2\n"
        },
        {
            "description": "Add a parameter to a function.",
            "file_content": "def bar(a):\n    return a * 2\n",
            "instruction": "Add a parameter 'b=5' to the function 'bar'.",
            "expected_output": "def bar(a, b=5):\n    return a * 2\n"
        },
        {
            "description": "Delete a class.",
            "file_content": "class MyClass:\n    def __init__(self):\n        pass\n\nclass AnotherClass:\n    pass",
            "instruction": "Delete the class named 'MyClass'.",
            "expected_output": "\n\nclass AnotherClass:\n    pass"
        },
        {
            "description": "Handle a more complex replacement in a class method.",
            "file_content": "class Calculator:\n    def add(self, a, b):\n        # This is a simple addition\n        return a + b\n",
            "instruction": "In the 'add' method of the 'Calculator' class, replace the implementation to return the sum as a string.",
            "expected_output": "class Calculator:\n    def add(self, a, b):\n        return str(a + b)\n"
        },
        {
            "description": "Instruction is unclear, should not change the file.",
            "file_content": "def my_func():\n    return 'hello'",
            "instruction": "Make it better.",
            "expected_output": "def my_func():\n    return 'hello'"
        }
    ]

    # We'll create a temporary file for the evolution config.
    config_path = Path("/tmp/evolution_line_replace/config.yaml")

    config_content = f"""
    task: "{task_description}"
    initial_program: "{initial_program}"
    test_cases:
    """

    for i, test in enumerate(test_cases):
        config_content += f"""
      - description: "{test['description']}"
        file_content: |-
{chr(10).join(['          ' + line for line in test['file_content'].split(chr(10))])}
        instruction: "{test['instruction']}"
        expected_output: |-
{chr(10).join(['          ' + line for line in test['expected_output'].split(chr(10))])}
    """

    with open(config_path, "w") as f:
        f.write(config_content)

    # Set the environment variable for the API key
    # IMPORTANT: Make sure the GEMINI_API_KEY is set in your environment.

    # Now, run the evolution.
    await run_evolution(config_path, population_size=10, num_islands=3, generations=10)

if __name__ == "__main__":
    asyncio.run(main())

