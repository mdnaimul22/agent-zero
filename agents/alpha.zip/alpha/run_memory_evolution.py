import sys
sys.path.append('/home/naimul/a1')
from pathlib import Path
import textwrap
import yaml


def main():
    """
    This script generates a valid YAML configuration file for the Alpha Evolve task.
    It does NOT run the evolution itself.
    """
    task_id = "ghost_retrieval_v5_programmatic"
    
    task_description = textwrap.dedent("""
        Evolve a **synchronous** Python function that implements a two-stage memory retrieval strategy by internally managing an asyncio event loop.
        The goal is to first quickly filter a large list of documents by keywords, and then re-rank the smaller, relevant subset using a more precise, but expensive, asynchronous similarity search function.

        The function signature must be:
        `def two_stage_retrieval_sync(query: str, documents: list[dict], rerank_func: callable) -> list[dict]`

        - `query`: The user's search query string.
        - `documents`: A list of dictionary objects, where each dict has at least a 'content' key with a string value.
        - `rerank_func`: An **awaitable (async)** function that will be passed in. The evolved code must handle its asynchronous nature.

        **Core Logic:**
        1.  **Keyword Filtering (Synchronous):**
            - Identify keywords from the `query`.
            - Create a candidate list of documents whose 'content' field contains at least one keyword (case-insensitive).

        2.  **Asynchronous Re-ranking:**
            - If the candidate list is not empty, the function must call the provided async `rerank_func`.
            - Since this function is synchronous, it **must use `asyncio.run()`** to execute the async `rerank_func`.
            - Example: `final_list = asyncio.run(rerank_func(query, candidate_list))`

        **Edge Cases:**
        - If no documents match the keywords, return an empty list without calling `rerank_func`.
        - If the initial list of documents is empty, return an empty list.
    """).strip()

    # The validation functions must be provided as strings of code.
    validate_simple_match_sync_str = textwrap.dedent("""
        async def mock_reranker(query, docs):
            return docs[::-1]
        
        # The get_input() function will be provided by the test harness.
        query, documents, _ = get_input()
        result = evolved_func(query, documents, mock_reranker)

        if not isinstance(result, list):
            raise AssertionError("Output must be a list.")
        
        if len(result) != 2:
            raise AssertionError(f"Expected 2 documents, but got {len(result)}")
        
        if result[0]['id'] != 3 or result[1]['id'] != 1:
            raise AssertionError(f"Output not correctly reranked. Got ids: {[d['id'] for d in result]}")
    """).strip()

    validate_no_match_sync_str = textwrap.dedent("""
        call_count = 0
        async def mock_reranker(query, docs):
            nonlocal call_count
            call_count += 1
            return docs

        query, documents, _ = get_input()
        result = evolved_func(query, documents, mock_reranker)

        if call_count > 0:
            raise AssertionError("rerank_func should not be called when there are no keyword matches.")

        if not isinstance(result, list) or len(result) != 0:
            raise AssertionError("Expected an empty list as output.")
    """).strip()

    tests = [
        {
            "description": "Test with a clear keyword match",
            "test_cases": [
                {
                    "input": [
                        "find a document about apples",
                        [
                            {'id': 1, 'content': 'Apples are a type of fruit.'},
                            {'id': 2, 'content': 'Oranges are citrus.'},
                            {'id': 3, 'content': 'A story about a red apple.'}
                        ],
                    ],
                    "validation_func": validate_simple_match_sync_str
                }
            ]
        },
        {
            "description": "Test with no keyword matches",
            "test_cases": [
                {
                    "input": [
                        "query about cars",
                        [
                            {'id': 1, 'content': 'Apples are a type of fruit.'},
                            {'id': 2, 'content': 'Oranges are citrus.'}
                        ],
                    ],
                    "validation_func": validate_no_match_sync_str
                }
            ]
        }
    ]

    config_dict = {
        'task_id': task_id,
        'task_description': task_description,
        'function_name': 'two_stage_retrieval_sync',
        'allowed_imports': ['re', 'asyncio'],
        'initial_program': textwrap.dedent(r"""
            import re
            import asyncio

            def two_stage_retrieval_sync(query: str, documents: list[dict], rerank_func: callable) -> list[dict]:
                if not documents:
                    return []
                
                keywords = re.findall(r'\w+', query.lower())
                if not keywords:
                    return []

                candidate_list = []
                for doc in documents:
                    doc_content_lower = doc.get('content', '').lower()
                    if any(keyword in doc_content_lower for keyword in keywords):
                        candidate_list.append(doc)
                
                if candidate_list:
                     return asyncio.run(rerank_func(query, candidate_list))
                
                return []
        """).strip(),
        'tests': tests
    }

    config_path = Path("/home/naimul/a1/alpha/tasks/task_determine_search_params.yaml")
    config_path.parent.mkdir(parents=True, exist_ok=True)
    
    def str_presenter(dumper, data):
        if len(data.splitlines()) > 1:
            return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='|')
        return dumper.represent_scalar('tag:yaml.org,2002:str', data)
    
    yaml.add_representer(str, str_presenter)
    
    with open(config_path, "w") as f:
        yaml.dump(config_dict, f, default_flow_style=False, sort_keys=False)

    print(f"YAML configuration file generated at: {config_path}")

if __name__ == "__main__":
    main()
