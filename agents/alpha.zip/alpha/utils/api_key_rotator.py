import threading

class Rotator:
    """
    A thread-safe rotator for API keys.
    Provides the current key and a method to rotate to the next one upon failure.
    """
    def __init__(self, api_keys, **kwargs):
        if not api_keys or not all(isinstance(k, str) and k for k in api_keys):
            raise ValueError("API keys list cannot be empty and must contain non-empty strings.")
        self.api_keys = api_keys
        self.current_key_index = 0
        self.lock = threading.Lock()

    def get_key(self):
        """
        Gets the current API key.
        """
        with self.lock:
            return self.api_keys[self.current_key_index]

    def rotate(self):
        """
        Rotates to the next key in the list.
        Returns the new key.
        """
        with self.lock:
            self.current_key_index = (self.current_key_index + 1) % len(self.api_keys)
            return self.api_keys[self.current_key_index]
